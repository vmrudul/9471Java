package com.example.demo.entity;

public enum Gender {
    MALE,
    FEMALE
}