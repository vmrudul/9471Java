//Write a program in Java to display the first 10 natural numbers.

public class Practical16{
    
  public static void main(String[] args)
    {     
    int i;
	System.out.println ("The first 10 natural numbers are:\n");
	for (i=1;i<=10;i++)
	{      
		System.out.println (i);
	}
System.out.println ("\n");
}
}
