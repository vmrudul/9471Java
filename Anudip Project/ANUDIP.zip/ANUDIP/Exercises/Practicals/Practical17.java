// Narrow casting

public class Practical17 {
 public static void main(String[] args) {
 double myDouble = 9.78;
 int myInt = (int) myDouble; 
 System.out.println(myDouble); 
 System.out.println(myInt); 
 }
}
