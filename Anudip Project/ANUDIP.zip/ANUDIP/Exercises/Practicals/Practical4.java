/*Example6:

Input:
Output:
Hello World 
Explanation:
Print Hello World on a single line.*/
public class Practical4 {

	public static void main(String[] args) {
String name="Hello World";
System.out.println(name);
	}

}
