import java.util.HashSet;
public class HashSet2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	HashSet<String> set=new HashSet<String>();
	set.add("ram");
	set.add("sham");
	set.add("love");
	set.add("kush");
	System.out.println(set);
	}

}
