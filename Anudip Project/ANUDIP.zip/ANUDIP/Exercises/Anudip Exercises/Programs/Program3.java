
public class Program3 {
		public static void main(String[] args)
		{		char ch = 'c';
			int num = 88;
			ch = 's';
		}
	}
