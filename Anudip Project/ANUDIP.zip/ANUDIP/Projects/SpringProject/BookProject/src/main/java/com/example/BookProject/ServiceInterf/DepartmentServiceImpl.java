package com.example.BookProject.ServiceInterf;

import java.util.List;

import com.example.BookProject.Department.Department;

public interface DepartmentServiceImpl {
	public List<Department> getDepartment();
	public Department addDepartment(Department department);
	
	

}
